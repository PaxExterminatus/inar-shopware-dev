import './component/inar-message';
import './component/inar-webar-manager';
import './component/inar-drop-wrapper';
import './extension/sw-product-detail-base';

import './extension/sw-file-input';
import './extension/sw-product-list';
import './init/api-service.init';
